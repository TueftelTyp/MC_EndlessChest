package de.tuefteltyp.infinitechest.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import de.tuefteltyp.infinitechest.GuiNetwork;
import de.tuefteltyp.infinitechest.PagedChestMenu;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Classic Minecraft inventory with a side-panel for named Endless Chest routing. */
public final class EndlessChestScreen extends AbstractContainerScreen<PagedChestMenu> {
    private static final Identifier GUI_TEXTURE = Identifier.fromNamespaceAndPath("infinitechest", "textures/gui/endless_chest_gui.png");
    private EditBox search;
    private EditBox ownName;
    private EditBox amount;
    private EditBox itemNumber;
    private int chosenSlot = -1;
    private int delayedSearch = -1;
    private String lastQuery = "";
    private List<String> targets = List.of();
    private int targetIndex;
    private String currentName = "";

    public EndlessChestScreen(PagedChestMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title, 330, 222);
    }

    @Override protected void init() {
        super.init();
        int x = leftPos, y = topPos;
        search = field(x+8, y+7, 154, "gui.infinitechest.search");
        search.setMaxLength(64);
        search.setResponder(value -> { delayedSearch = 6; clearSelection(); });
        ownName = field(x+176, y+7, 80, "gui.infinitechest.name");
        ownName.setMaxLength(24);
        ownName.setValue(currentName);
        addRenderableWidget(Button.builder(Component.translatable("gui.infinitechest.rename"), b -> {
            ClientPlayNetworking.send(new GuiNetwork.Rename(ownName.getValue()));
        }).bounds(x+261, y+7, 62, 18).build());

        addRenderableWidget(Button.builder(Component.literal("<"), b -> sendPage(0)).bounds(x+176, y+31, 20, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> sendPage(1)).bounds(x+303, y+31, 20, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.infinitechest.sort"), b -> sendPage(2))
            .bounds(x+176, y+53, 147, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.infinitechest.withdraw"), b -> sendWithdraw())
            .bounds(x+176, y+76, 147, 18).build());
        itemNumber = field(x+176, y+98, 56, "gui.infinitechest.slot");
        amount = field(x+238, y+98, 85, "gui.infinitechest.amount");
        amount.setValue("64");
        addRenderableWidget(Button.builder(Component.literal("<"), b -> changeTarget(-1))
            .bounds(x+176, y+121, 20, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> changeTarget(1))
            .bounds(x+303, y+121, 20, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.infinitechest.send"), b -> sendTransfer())
            .bounds(x+176, y+146, 147, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.infinitechest.refresh"), b ->
            ClientPlayNetworking.send(new GuiNetwork.TargetListRequest(0)))
            .bounds(x+176, y+174, 147, 18).build());
        ClientPlayNetworking.send(new GuiNetwork.TargetListRequest(0));
    }

    private EditBox field(int x, int y, int w, String key) {
        EditBox edit = new EditBox(this.font, x, y, w, 17, Component.translatable(key));
        edit.setHint(Component.translatable(key));
        edit.setMaxLength(64);
        addRenderableWidget(edit);
        return edit;
    }

    public void applyTargets(String own, String json) {
        if (ownName == null) return;
        currentName = own;
        ownName.setValue(own);
        String previous = targetIndex >= 0 && targetIndex < targets.size() ? targets.get(targetIndex) : "";
        try {
            List<String> fresh = new ArrayList<>();
            for (JsonElement item : JsonParser.parseString(json).getAsJsonArray()) {
                String value = item.getAsString();
                if (!value.isBlank()) fresh.add(value);
            }
            targets = List.copyOf(fresh);
            targetIndex = Math.max(0, targets.indexOf(previous));
        } catch (RuntimeException badPacket) {
            targets = List.of();
            targetIndex = 0;
        }
    }

    private void changeTarget(int direction) {
        if (targets.isEmpty()) return;
        targetIndex = Math.floorMod(targetIndex + direction, targets.size());
    }

    @Override protected void containerTick() {
        super.containerTick();
        if (delayedSearch >= 0 && --delayedSearch == 0) {
            String query = search.getValue();
            if (!query.equals(lastQuery)) {
                lastQuery = query;
                ClientPlayNetworking.send(new GuiNetwork.Search(query));
            }
        }
    }

    private void clearSelection() {
        chosenSlot = -1;
        if (itemNumber != null) itemNumber.setValue("");
    }

    private void sendPage(int action) {
        clearSelection();
        ClientPlayNetworking.send(new GuiNetwork.Action(action));
    }

    private int selectedSlot() {
        if (itemNumber != null && !itemNumber.getValue().isBlank()) {
            try { return Integer.parseInt(itemNumber.getValue().strip()) - 1; }
            catch (NumberFormatException ignored) { return -1; }
        }
        return chosenSlot;
    }

    private int count() {
        try { return Integer.parseInt(amount.getValue().strip()); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private void sendWithdraw() {
        int idx = selectedSlot();
        int quantity = count();
        if (idx >= 0 && idx < PagedChestMenu.STORAGE_SLOTS && quantity >= 1 && quantity <= 64)
            ClientPlayNetworking.send(new GuiNetwork.Withdraw(idx, quantity));
    }

    private void sendTransfer() {
        int idx = selectedSlot();
        int quantity = count();
        if (idx < 0 || idx >= PagedChestMenu.STORAGE_SLOTS || quantity < 1 || quantity > 2304 || targets.isEmpty()) return;
        ClientPlayNetworking.send(new GuiNetwork.NamedTransfer(idx, targets.get(targetIndex), quantity));
    }

    @Override protected void slotClicked(Slot slot, int slotId, int mouseButton,
            net.minecraft.world.inventory.ContainerInput clickType) {
        if (slot != null && slotId >= 0 && slotId < PagedChestMenu.STORAGE_SLOTS) {
            chosenSlot = slotId;
            if (this.menu.getCarried().isEmpty()) return;
        }
        super.slotClicked(slot, slotId, mouseButton, clickType);
    }

    @Override public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_TEXTURE, leftPos, topPos,
            0, 0, imageWidth, imageHeight, imageWidth, imageHeight);
    }

    @Override protected void extractLabels(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        graphics.text(font, Component.translatable("gui.infinitechest.inventory"), 8, 128, 0x404040, false);
        graphics.text(font, Component.literal((menu.page()+1)+" / "+menu.pages()), 235, 36, 0x404040, false);
        String label = targets.isEmpty() ? "–" : targets.get(Math.min(targetIndex, targets.size()-1));
        if (label.length() > 17) label = label.substring(0, 16) + "…";
        graphics.text(font, Component.literal(label), 200, 126, 0x404040, false);
        graphics.text(font, Component.translatable("gui.infinitechest.target"), 177, 197, 0x404040, false);
        graphics.text(font, Component.literal(chosenSlot < 0 ? "Slot: –" : "Slot: " + (chosenSlot+1)), 177, 208, 0x404040, false);
    }
}
