package de.tuefteltyp.infinitechest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/** Server-thread-only directory, persistent per world and unique across dimensions.
 * Entries for unloaded chests stay reserved until their owner is actually removed.
 */
public final class ChestDirectory {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();
    private static Path database;
    private static boolean ready;
    private ChestDirectory() { }

    public record Entry(String name, String dimension, BlockPos pos) { }
    public enum RenameResult { SUCCESS, INVALID, TAKEN, UNAVAILABLE }

    private static String key(String name) { return NameRules.key(name); }
    private static String dimension(ServerLevel level) { return level.dimension().identifier().toString(); }
    private static boolean at(Entry entry, ServerLevel level, BlockPos pos) {
        return entry.dimension().equals(dimension(level)) && entry.pos().equals(pos);
    }

    public static void open(MinecraftServer server) {
        ENTRIES.clear();
        ready = false;
        database = server.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("endlesschest_names.json");
        if (!Files.exists(database)) { ready = true; return; }
        try (Reader reader = Files.newBufferedReader(database, StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            for (JsonElement element : root.getAsJsonArray("chests")) {
                JsonObject item = element.getAsJsonObject();
                String name = NameRules.normalize(item.get("name").getAsString());
                String dim = Identifier.parse(item.get("dimension").getAsString()).toString();
                BlockPos pos = new BlockPos(item.get("x").getAsInt(), item.get("y").getAsInt(), item.get("z").getAsInt());
                if (name.isEmpty() || ENTRIES.containsKey(key(name))) throw new IOException("Duplicate or invalid chest name in directory");
                ENTRIES.put(key(name), new Entry(name, dim, pos));
            }
            ready = true;
        } catch (Exception error) {
            ENTRIES.clear();
            InfiniteChestMod.LOGGER.error("Name database could not be loaded. Naming/transfer locked to protect existing names: " + database, error);
        }
    }

    public static void close() { ENTRIES.clear(); database = null; ready = false; }

    private static boolean persist(Map<String, Entry> entries) {
        if (!ready || database == null) return false;
        Path temp = database.resolveSibling(database.getFileName().toString() + ".tmp");
        try {
            JsonArray array = new JsonArray();
            for (Entry entry : entries.values()) {
                JsonObject element = new JsonObject();
                element.addProperty("name", entry.name());
                element.addProperty("dimension", entry.dimension());
                element.addProperty("x", entry.pos().getX());
                element.addProperty("y", entry.pos().getY());
                element.addProperty("z", entry.pos().getZ());
                array.add(element);
            }
            JsonObject root = new JsonObject();
            root.add("chests", array);
            Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(temp, database, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp, database, StandardCopyOption.REPLACE_EXISTING);
            }
            ENTRIES.clear();
            ENTRIES.putAll(entries);
            return true;
        } catch (IOException error) {
            InfiniteChestMod.LOGGER.error("Failed to persist Endless Chest names. No rename was applied.", error);
            try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
            return false;
        }
    }

    /** Called on a genuine new block placement: always generate a fresh random identity. */
    public static String registerNew(ServerLevel level, InfiniteChestBlockEntity chest) {
        if (!ready) return "";
        String name;
        do { name = "Chest-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT); }
        while (ENTRIES.containsKey(key(name)));
        Map<String, Entry> replacement = new LinkedHashMap<>(ENTRIES);
        replacement.entrySet().removeIf(entry -> at(entry.getValue(), level, chest.getBlockPos()));
        replacement.put(key(name), new Entry(name, dimension(level), chest.getBlockPos().immutable()));
        if (!persist(replacement)) return "";
        chest.updateNetworkName(name);
        return name;
    }

    public static String ensure(ServerLevel level, InfiniteChestBlockEntity chest) {
        if (!ready) return "";
        BlockPos pos = chest.getBlockPos();
        String current = NameRules.normalize(chest.networkName());
        // Existing mapping at the location always wins; this preserves names across upgrades.
        for (Entry entry : ENTRIES.values()) {
            if (at(entry, level, pos)) {
                if (!entry.name().equals(chest.networkName())) chest.updateNetworkName(entry.name());
                return entry.name();
            }
        }
        if (current.isEmpty() || ENTRIES.containsKey(key(current))) {
            do { current = "Chest-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT); }
            while (ENTRIES.containsKey(key(current)));
        }
        Map<String, Entry> replacement = new LinkedHashMap<>(ENTRIES);
        replacement.put(key(current), new Entry(current, dimension(level), pos.immutable()));
        if (!persist(replacement)) return "";
        chest.updateNetworkName(current);
        return current;
    }

    public static RenameResult rename(ServerLevel level, InfiniteChestBlockEntity chest, String requested) {
        if (!ready || ensure(level, chest).isEmpty()) return RenameResult.UNAVAILABLE;
        String name = NameRules.normalize(requested);
        if (name.isEmpty()) return RenameResult.INVALID;
        Entry taken = ENTRIES.get(key(name));
        if (taken != null && !at(taken, level, chest.getBlockPos())) return RenameResult.TAKEN;
        if (name.equals(chest.networkName())) return RenameResult.SUCCESS;
        Map<String, Entry> replacement = new LinkedHashMap<>(ENTRIES);
        replacement.entrySet().removeIf(entry -> at(entry.getValue(), level, chest.getBlockPos()));
        replacement.put(key(name), new Entry(name, dimension(level), chest.getBlockPos().immutable()));
        if (!persist(replacement)) return RenameResult.UNAVAILABLE;
        chest.updateNetworkName(name);
        return RenameResult.SUCCESS;
    }

    public static boolean release(ServerLevel level, BlockPos pos) {
        if (!ready) return false;
        Map<String, Entry> replacement = new LinkedHashMap<>(ENTRIES);
        boolean changed = replacement.entrySet().removeIf(entry -> at(entry.getValue(), level, pos));
        return !changed || persist(replacement);
    }

    public static List<String> namesExcept(ServerLevel level, BlockPos from) {
        if (!ready) return List.of();
        return ENTRIES.values().stream().filter(entry -> !at(entry, level, from))
            .map(Entry::name).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }

    public static Entry find(String name) {
        return ready && name != null ? ENTRIES.get(key(name.strip())) : null;
    }

    public static ServerLevel resolve(MinecraftServer server, Entry entry) {
        if (entry == null) return null;
        Identifier id;
        try { id = Identifier.parse(entry.dimension()); }
        catch (RuntimeException badId) { return null; }
        ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, id);
        return server.getLevel(dimension);
    }
}
