# MC Infinite Storage v1.1 (source candidate, NOT build-verified)

**Author:** TueftelTyp  
**Target:** Minecraft Java Edition 26.3, Fabric, Java 25  
**Important:** Source was statically inspected, but not compiled or game-tested in this environment. This is not a certified release. Back up worlds before any testing.

## Purpose

A new and independent Infinite Chest block. Ordinary vanilla chests are not replaced. The block has its own block/item models, textures, icon, logo and crafting recipe.

## Current interface and actions

- Right-click the block with an item to deposit the held stack.
- Right-click with an empty hand for storage stats.
- Sneak-right-click to withdraw the last stored stack.
- `/is list X Y Z [page]` shows sorted item variants with clickable withdraw commands.
- `/is search X Y Z <term>` filters variants, displayed by each player's own selection snapshot.
- `/is withdraw X Y Z <index> <amount>` withdraws up to one standard item stack; list or search first.
- `/is send SRC_X SRC_Y SRC_Z <index> DST_X DST_Y DST_Z <amount>` transfers to another Infinite Chest or supported ordinary inventory, after list/search.
- Mod Menu + Cloth Config exposes several configuration options. **Server configuration is authoritative**, so multiplayer players cannot change server rules using client Mod Menu.

## Build (on your machine)

Install Java 25 and the Gradle 9 version appropriate for Loom 1.19. The package does not include Gradle wrapper binaries. Open the project in a Gradle-enabled IDE or run `gradle build`. Mod dependencies: Fabric API 0.166.2+26.3, Fabric Loader 0.20.1, Mod Menu 21.0.1, Cloth Config 26.3.159. Ensure Maven is accessible.

## Safety and remaining shortcomings

- A player cannot normally break a **nonempty** Infinite Chest, including in creative, to avoid losing storage data. Empty it before mining.
- Server commands or third-party block-replacement mods may still delete a block entity and its data. **Always make world backups.**
- Storage remains bounded by RAM, the serialized block-entity list and the Minecraft storage format. It is not mathematically infinite; performance worsens with very large numbers of different stacks.
- The current item browser uses clickable chat lines, **not** the requested polished search-and-sort inventory GUI. No claim is made that all requested v1.1 GUI functionality is implemented.
- Transfers only target currently loaded positions in the **same dimension**. Double chests and other special inventories are not exhaustively validated.
- The implementation has not passed a real compile/run test in this environment.

## Local QA before releasing

1. `gradle clean build`, inspect all compiler errors.
2. Start a fresh world; confirm item and block display in creative inventory, recipe and right-click behavior.
3. Test storage across save/restart, stack components and heavy volumes.
4. Verify inventory-full withdrawals, search variant indices, vanilla/full destination transfers, player rights and multiplayer concurrency.
5. Test attempts to break nonempty chests in survival and creative, explosions, piston interaction and `/setblock`.
6. Inspect the final built JAR's included JSON, models and texture assets.

MIT license.
