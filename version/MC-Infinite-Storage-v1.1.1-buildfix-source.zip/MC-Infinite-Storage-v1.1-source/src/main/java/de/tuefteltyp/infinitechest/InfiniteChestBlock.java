package de.tuefteltyp.infinitechest;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

/** A separate Minecraft block. Ordinary chests are never replaced or modified. */
public final class InfiniteChestBlock extends BaseEntityBlock {
    public InfiniteChestBlock(Properties properties) { super(properties); }
    @Override protected RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Nullable @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new InfiniteChestBlockEntity(pos, state);
    }
    @Override protected InteractionResult useItemOn(ItemStack held, BlockState state, Level level,
            BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof InfiniteChestBlockEntity chest)) return InteractionResult.PASS;
        if (player.isShiftKeyDown()) {
            ItemStack extracted = chest.takeLast();
            if (!extracted.isEmpty()) {
                player.getInventory().add(extracted);
                if (!extracted.isEmpty()) player.drop(extracted, false);
                player.displayClientMessage(Component.translatable("message.infinitechest.withdraw", extracted.getCount()), true);
            }
            return InteractionResult.SUCCESS;
        }
        if (!held.isEmpty()) {
            int amount = held.getCount();
            chest.deposit(held.copy());
            held.shrink(amount);
            player.displayClientMessage(Component.translatable("message.infinitechest.deposit", amount), true);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.TRY_WITH_EMPTY_HAND;
    }
    @Override protected InteractionResult useWithoutItem(BlockState state, Level level,
            BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide() && level.getBlockEntity(pos) instanceof InfiniteChestBlockEntity chest) {
            if (player.isShiftKeyDown()) {
                ItemStack extracted = chest.takeLast();
                if (!extracted.isEmpty()) {
                    player.getInventory().add(extracted);
                    if (!extracted.isEmpty()) player.drop(extracted, false);
                }
            } else {
                player.displayClientMessage(Component.translatable("message.infinitechest.info", chest.stackTypes(), chest.totalCount()), false);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
