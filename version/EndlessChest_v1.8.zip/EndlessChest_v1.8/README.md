# Endless Chest v1.8 - Compiler-API-Korrektur (unverifizierter Kandidat)

**Keine vollstaendige Release-Version.** Dieser Stand beseitigt die fuenf im Gradle-Log aus v1.7 sichtbaren Fehler durch folgende Aenderungen:
- `DirectionProperty` durch `EnumProperty<Direction>` ersetzt; `HORIZONTAL_FACING` ist eine EnumProperty.
- `ContainerUser` von `net.minecraft.world.ContainerUser` auf `net.minecraft.world.entity.ContainerUser` korrigiert.

Die bisherige Inventar-GUI hat nur 54 Slots. Eine fluessige Deckelanimation, grafische Suche und Sortierung, GUI-Seitenwechsel und GUI-Transfers sind weiterhin nicht implementiert. Der bestehende statische Open/Close-Modellwechsel bleibt erhalten.

Der Code wurde hier **nicht** mit Java 25 / Fabric 26.3 kompiliert (JDK 21, Netzwerk / Gradle-Abhaengigkeiten nicht verfuegbar).

Build unter Java 25: `gradle clean build`. Vor Spieltests Welt sichern; nicht mit wertvollen Items testen.

## Original README (v1.7)

# Endless Chest v1.7 (Build candidate)

Minecraft 26.3 / Fabric / Java 25. Author: TueftelTyp.

## Changes from v1.6
- Right-click opens a real vanilla six-row storage window instead of sending only a status message.
- Block is directional and uses a 3D model composed of a body, a separate lid and corner pieces.
- Opening/closing the inventory switches the model to an open/closed lid state.
- The server-side inventory persists changes in the same block entity data as before.
- Previous `/is` commands and the configurable crafting recipe are retained.

## Important limitations
- The lid switches between states; **this is not a fluid animated lid**. A custom block entity renderer is still needed for smooth motion.
- The vanilla inventory menu shows only the first 54 stacks. The remaining stacks are preserved but not paged within the GUI. Search, sort, paging and transfer currently remain available through `/is` commands only.
- No full Minecraft/Gradle build or in-game test was possible in this environment (JDK 21, no Gradle, no Maven network).
- Treat this archive as an **unverified build candidate**. Create a world backup before using this version. Never test with valuable storage items.

## Build
Use Java 25: `gradle clean build`.

## Recipe
By default the recipe is 8 diamond blocks around a chest, configurable via `config/endlesschest-recipe.json` as in v1.6.
