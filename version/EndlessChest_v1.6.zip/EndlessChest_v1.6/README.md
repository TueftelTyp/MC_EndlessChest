# Endless Chest v1.5 — Graphics integration

**Author:** TueftelTyp  
**Target:** Minecraft 26.3 / Fabric / Java 25

This version includes the complete new graphics set. Actual block textures use 64 x 64 pixel files under `assets/infinitechest/textures/block/`. The static block model references front, sides, rear, top and bottom. The item is rendered from the block model in inventory and hand, with model display transforms. The mod icon is installed at `src/main/resources/icon.png`.

A full-size pixel-art GUI concept and control atlas are stored under `assets/infinitechest/textures/gui/`, but **the Java GUI is not implemented yet**. The existing command-based storage interface remains unchanged. Neither an animated lid nor 3-D projected buckles are implemented. The world block remains a cube; its front does not currently rotate with player-facing direction.

The `promotional/` directory contains a banner for documentation, not an in-game model. The separately supplied graphics ZIP contains all original designs, prepared 64px block textures, icons, and UI art. Original concept art is much larger than Minecraft tile textures and is not used directly on cube faces.

Use `gradle clean build` on Java 25. This asset integration was statically validated; a complete Minecraft run / build was not performed here. Keep backups of worlds during testing.

# Endless Chest v1.4

## Resource graphics repair

This revision replaces all previous placeholder-like 16x16 block textures with purpose-designed 64x64 pixel-art textures for the dedicated Endless Chest block. The same block model is used by the inventory item model, and item assets include the 26.3 items/*.json definition.

The graphical artwork depicts a dark navy reinforced storage chest with golden rails, luminous cyan trim, purple jewel, and an infinity emblem. The chest is a custom block, not a replacement for vanilla chests.

**Resource references:**
- assets/infinitechest/blockstates/infinite_chest.json -> infinitechest:block/infinite_chest
- assets/infinitechest/models/block/infinite_chest.json -> up/down/north/east/south/west 64px textures
- assets/infinitechest/items/infinite_chest.json -> infinitechest:item/infinite_chest
- assets/infinitechest/models/item/infinite_chest.json -> block model
- assets/infinitechest/icon.png and icon.png -> mod listing icon

The front emblem is on the model north face; the block currently does not rotate with placement direction. No custom graphical inventory screen has yet been implemented; existing storage interactions remain command based.

This is a resource fix candidate and **has not been compiled or tested in Minecraft 26.3**. Compile with Java 25 and Gradle (`gradle clean build`).

Author: TueftelTyp.

---

# Endless Chest v1.3 (source candidate, NOT build-verified)

**Author:** TueftelTyp  
**Target:** Minecraft Java Edition 26.3, Fabric, Java 25  
**Important:** Source was statically inspected, but not compiled or game-tested in this environment. This is not a certified release. Back up worlds before any testing.

## Purpose

A new and independent Infinite Chest block. Ordinary vanilla chests are not replaced. The block has its own block/item models, textures, icon, logo and crafting recipe.

## Current interface and actions

- Right-click the block with an item to deposit the held stack.
- Right-click with an empty hand for storage stats.
- Sneak-right-click to withdraw the last stored stack.
- `/is list X Y Z [page]` shows sorted item variants with clickable withdraw commands.
- `/is search X Y Z <term>` filters variants, displayed by each player's own selection snapshot.
- `/is withdraw X Y Z <index> <amount>` withdraws up to one standard item stack; list or search first.
- `/is send SRC_X SRC_Y SRC_Z <index> DST_X DST_Y DST_Z <amount>` transfers to another Infinite Chest or supported ordinary inventory, after list/search.
- Mod Menu + Cloth Config exposes several configuration options. **Server configuration is authoritative**, so multiplayer players cannot change server rules using client Mod Menu.

## Build (on your machine)

Install Java 25 and the Gradle 9 version appropriate for Loom 1.19. The package does not include Gradle wrapper binaries. Open the project in a Gradle-enabled IDE or run `gradle build`. Mod dependencies: Fabric API 0.166.2+26.3, Fabric Loader 0.20.1, Mod Menu 21.0.1, Cloth Config 26.3.159. Ensure Maven is accessible.

## Safety and remaining shortcomings

- A player cannot normally break a **nonempty** Infinite Chest, including in creative, to avoid losing storage data. Empty it before mining.
- Server commands or third-party block-replacement mods may still delete a block entity and its data. **Always make world backups.**
- Storage remains bounded by RAM, the serialized block-entity list and the Minecraft storage format. It is not mathematically infinite; performance worsens with very large numbers of different stacks.
- The current item browser uses clickable chat lines, **not** the requested polished search-and-sort inventory GUI. No claim is made that all requested v1.3 GUI functionality is implemented.
- Transfers only target currently loaded positions in the **same dimension**. Double chests and other special inventories are not exhaustively validated.
- The implementation has not passed a real compile/run test in this environment.

## Local QA before releasing

1. `gradle clean build`, inspect all compiler errors.
2. Start a fresh world; confirm item and block display in creative inventory, recipe and right-click behavior.
3. Test storage across save/restart, stack components and heavy volumes.
4. Verify inventory-full withdrawals, search variant indices, vanilla/full destination transfers, player rights and multiplayer concurrency.
5. Test attempts to break nonempty chests in survival and creative, explosions, piston interaction and `/setblock`.
6. Inspect the final built JAR's included JSON, models and texture assets.

MIT license.


## v1.3 compatibility corrections

- Updated the creative-tab event to the 26.3 API.
- Updated player feedback to sendOverlayMessage/sendSystemMessage.
- Prevented full-inventory extraction from spawning untracked item entities; leftovers are restored.
- Corrected squared-distance type to double and prevented destination chunk loading.
- Build and in-game testing still required (Java 25).


## Crafting recipe configuration (v1.6) / Crafting-Rezept anpassen

Default: 8 diamond blocks around 1 vanilla chest (3x3).
Standard: 8 Diamantblöcke um eine normale Truhe (3x3).

```
[D][D][D]
[D][C][D]
[D][D][D]
D = minecraft:diamond_block; C = minecraft:chest
```

The recipe is configurable through `config/endlesschest-recipe.json` (generated at the first mod initialization).
Each of the nine `slots` can be changed to an item identifier (`minecraft:iron_block`), a tag (`#minecraft:planks`), or an empty string for an empty slot. Edit the JSON on the SERVER for multiplayer. A Mod Menu page also lets you edit the nine fields; edits on a client are local and do not change a dedicated server.

The config is validated (nine entries, restricted identifiers, at least one ingredient). To activate a changed recipe: **restart the server or world**, then, as an operator, run `/datapack enable "file/endlesschest_recipe"` if the pack is not yet enabled, followed by `/reload`. Check `/datapack list`. The pack is generated in `<world>/datapacks/endlesschest_recipe`, with 26.3 data-pack format 121, and overrides the bundled default recipe. If config is missing or invalid the mod falls back to the default recipe; a malformed existing config is not overwritten.

**Note:** The complete Minecraft 26.3 build is not validated in this environment. The server start API and Mod Menu fields need confirmation with `gradle clean build`. Data-pack activation/reload is deliberately NOT executed automatically to avoid server lifecycle re-entrancy. Back up your world before trying new development builds.
