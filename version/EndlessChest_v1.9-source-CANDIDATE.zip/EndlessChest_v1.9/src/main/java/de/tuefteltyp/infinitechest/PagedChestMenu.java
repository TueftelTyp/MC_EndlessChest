package de.tuefteltyp.infinitechest;

import net.minecraft.network.chat.Component;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Vanilla six-row chest protocol for compatibility: 45 real item slots plus
 * 9 locked controls. Page/sort are implemented SERVER-SIDE. This is not the
 * final custom-styled search screen; it is a working navigation milestone.
 */
public final class PagedChestMenu extends AbstractContainerMenu {
    private static final int STORAGE_SLOTS = 45;
    private final InfiniteChestBlockEntity chest;
    private final Inventory playerInventory;
    private final SimpleContainer buttons = new SimpleContainer(9);
    private final Container pageContainer = new PageContainer();
    private int page = 0;
    private boolean quantitySort = false;
    private List<Integer> indexOrder = List.of();

    public PagedChestMenu(int id, Inventory inventory, InfiniteChestBlockEntity chest) {
        super(MenuType.GENERIC_9x6, id); // Vanilla client constructs the matching ChestMenu
        this.chest = chest;
        this.playerInventory = inventory;
        refresh();
        for (int row = 0; row < 5; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(pageContainer, row * 9 + column, 8 + column * 18, 18 + row * 18));
            }
        }
        updateControls();
        for (int i = 0; i < 9; i++) {
            addSlot(new Slot(buttons, i, 8 + i * 18, 18 + 5 * 18) {
                @Override public boolean mayPlace(ItemStack stack) { return false; }
                @Override public boolean mayPickup(Player player) { return false; }
            });
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 139 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 197));
        }
        chest.startOpen(inventory.player);
    }

    private void refresh() {
        ArrayList<Integer> indices = new ArrayList<>();
        for (int i = 0; i <= chest.highestUsedIndex(); i++) {
            if (!chest.getStored(i).isEmpty()) indices.add(i);
        }
        Comparator<Integer> cmp = quantitySort
            ? Comparator.comparingInt((Integer idx) -> chest.getStored(idx).getCount()).reversed()
            : Comparator.comparing(idx -> chest.getStored(idx).getHoverName().getString().toLowerCase(Locale.ROOT));
        indices.sort(cmp.thenComparingInt(i -> i));
        indexOrder = indices;
        page = Math.min(page, maxPage());
    }

    private int maxPage() { return Math.max(0, (indexOrder.size() - 1) / STORAGE_SLOTS); }
    private int backingIndex(int visibleIndex) {
        int index = page * STORAGE_SLOTS + visibleIndex;
        if (visibleIndex < 0 || visibleIndex >= STORAGE_SLOTS || index < 0 || index >= indexOrder.size()) return -1;
        return indexOrder.get(index);
    }
    private static ItemStack icon(net.minecraft.world.item.Item item, Component name) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, name);
        return stack;
    }
    private void updateControls() {
        buttons.setItem(0, icon(Items.ARROW, Component.translatable("gui.infinitechest.previous")));
        buttons.setItem(1, icon(Items.ARROW, Component.translatable("gui.infinitechest.next")));
        buttons.setItem(2, icon(Items.COMPARATOR, Component.translatable(quantitySort ? "gui.infinitechest.by_name" : "gui.infinitechest.by_amount")));
        buttons.setItem(3, icon(Items.BOOK, Component.translatable("gui.infinitechest.page", page + 1, maxPage() + 1)));
        buttons.setItem(4, icon(Items.SPYGLASS, Component.translatable("gui.infinitechest.search_hint")));
        buttons.setItem(5, icon(Items.HOPPER, Component.translatable("gui.infinitechest.transfer_hint")));
        buttons.setItem(6, icon(Items.CHEST, Component.translatable("gui.infinitechest.stacks", indexOrder.size())));
        buttons.setItem(7, ItemStack.EMPTY);
        buttons.setItem(8, ItemStack.EMPTY);
    }

    @Override public void clicked(int index, int button, ContainerInput action, Player player) {
        if (index >= STORAGE_SLOTS && index < 54) {
            if (!player.level().isClientSide() && chest.stillValid(player)) {
                int control = index - STORAGE_SLOTS;
                if (control == 0) page = Math.max(0, page - 1);
                else if (control == 1) page = Math.min(maxPage(), page + 1);
                else if (control == 2) quantitySort = !quantitySort;
                refresh();
                updateControls();
                broadcastFullState();
            }
            return;
        }
        if (!chest.stillValid(player)) return;
        super.clicked(index, button, action, player);
        if (!player.level().isClientSide()) {
            refresh();
            updateControls();
            broadcastChanges();
        }
    }

    @Override public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (!chest.stillValid(player) || slotIndex < 0 || slotIndex >= slots.size()) return ItemStack.EMPTY;
        if (slotIndex >= STORAGE_SLOTS && slotIndex < 54) return ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack original = slot.getItem();
        ItemStack returnStack = original.copy();
        if (slotIndex < STORAGE_SLOTS) {
            ItemStack toMove = original.copy();
            if (!moveItemStackTo(toMove, 54, slots.size(), false)) return ItemStack.EMPTY;
            slot.setByPlayer(toMove);
        } else {
            ItemStack toMove = original.copy();
            chest.deposit(toMove);
            slot.setByPlayer(ItemStack.EMPTY);
        }
        slot.setChanged();
        refresh();
        updateControls();
        broadcastChanges();
        return returnStack;
    }

    @Override public void removed(Player player) {
        super.removed(player);
        chest.stopOpen(player);
    }

    @Override public boolean stillValid(Player player) { return chest.stillValid(player); }

    private final class PageContainer implements Container {
        @Override public int getContainerSize() { return STORAGE_SLOTS; }
        @Override public boolean isEmpty() { return indexOrder.isEmpty(); }
        @Override public ItemStack getItem(int index) {
            int actual = backingIndex(index);
            return actual < 0 ? ItemStack.EMPTY : chest.getStored(actual);
        }
        @Override public ItemStack removeItem(int index, int count) {
            int actual = backingIndex(index);
            return actual < 0 ? ItemStack.EMPTY : chest.removeStored(actual, count);
        }
        @Override public ItemStack removeItemNoUpdate(int index) {
            int actual = backingIndex(index);
            if (actual < 0) return ItemStack.EMPTY;
            ItemStack removed = chest.getStored(actual).copy();
            chest.setStored(actual, ItemStack.EMPTY);
            return removed;
        }
        @Override public void setItem(int index, ItemStack stack) {
            int actual = backingIndex(index);
            if (actual < 0) {
                if (!stack.isEmpty()) chest.deposit(stack);
            } else {
                chest.setStored(actual, stack);
            }
        }
        @Override public void setChanged() { chest.setChanged(); }
        @Override public boolean stillValid(Player player) { return chest.stillValid(player); }
        @Override public void clearContent() { /* never clear hidden pages */ }
    }
}
