package de.tuefteltyp.infinitechest;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Server-thread-owned persistent inventory; component-exact stacks only. */
public final class InfiniteChestBlockEntity extends BlockEntity {
    private final List<ItemStack> stacks = new ArrayList<>();

    public InfiniteChestBlockEntity(BlockPos pos, BlockState state) {
        super(InfiniteChestMod.CHEST_BE, pos, state);
    }

    /** The caller retains its own stack. Reject amounts that cannot be saved safely. */
    public void deposit(ItemStack incoming) {
        if (incoming == null || incoming.isEmpty()) return;
        ItemStack remaining = incoming.copy();
        for (ItemStack stored : stacks) {
            if (!ItemStack.isSameItemSameComponents(stored, remaining)) continue;
            int moved = Math.min(stored.getMaxStackSize() - stored.getCount(), remaining.getCount());
            if (moved > 0) {
                stored.grow(moved);
                remaining.shrink(moved);
            }
            if (remaining.isEmpty()) break;
        }
        while (!remaining.isEmpty()) {
            int moved = Math.min(remaining.getCount(), remaining.getMaxStackSize());
            stacks.add(remaining.copyWithCount(moved));
            remaining.shrink(moved);
        }
        setChanged();
    }

    public long countMatching(ItemStack key) {
        if (key == null || key.isEmpty()) return 0;
        long total = 0;
        for (ItemStack stack : stacks) {
            if (ItemStack.isSameItemSameComponents(stack, key)) total += stack.getCount();
        }
        return total;
    }

    /** Returns at most one vanilla stack. Never subtracts more than available. */
    public ItemStack removeMatching(ItemStack key, int requested) {
        if (key == null || key.isEmpty() || requested <= 0) return ItemStack.EMPTY;
        int wanted = Math.min(requested, key.getMaxStackSize());
        int available = (int) Math.min(wanted, countMatching(key));
        if (available == 0) return ItemStack.EMPTY;
        int left = available;
        for (int i = stacks.size() - 1; i >= 0 && left > 0; i--) {
            ItemStack stored = stacks.get(i);
            if (!ItemStack.isSameItemSameComponents(stored, key)) continue;
            int n = Math.min(left, stored.getCount());
            stored.shrink(n);
            left -= n;
            if (stored.isEmpty()) stacks.remove(i);
        }
        setChanged();
        return key.copyWithCount(available - left);
    }

    public ItemStack takeLast() {
        if (stacks.isEmpty()) return ItemStack.EMPTY;
        ItemStack stack = stacks.remove(stacks.size() - 1);
        setChanged();
        return stack;
    }

    public boolean isStorageEmpty() { return stacks.isEmpty(); }

    public int stackTypes() {
        List<ItemStack> kinds = new ArrayList<>();
        for (ItemStack stack : stacks) {
            boolean exists = false;
            for (ItemStack key : kinds) {
                if (ItemStack.isSameItemSameComponents(key, stack)) { exists = true; break; }
            }
            if (!exists) kinds.add(stack);
        }
        return kinds.size();
    }

    public long totalCount() {
        long total = 0;
        for (ItemStack s : stacks) total += s.getCount();
        return total;
    }

    public List<ItemStack> snapshot() { return stacks.stream().map(ItemStack::copy).toList(); }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.store("stored", ItemStack.CODEC.listOf(), stacks);
    }

    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        stacks.clear();
        input.read("stored", ItemStack.CODEC.listOf()).ifPresent(saved ->
            saved.stream().filter(s -> s != null && !s.isEmpty()).map(ItemStack::copy).forEach(stacks::add));
    }
}
