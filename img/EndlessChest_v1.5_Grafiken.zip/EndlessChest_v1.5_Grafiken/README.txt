Endless Chest v1.5 - separated graphics package
Author: TueftelTyp

block/: 64x64 Minecraft block-face textures (front, side, rear, top, bottom).
gui/: GUI concept and control atlas (not yet active in Minecraft).
Originale/: original large design graphics and banners.
icon_128/256/512: mod icon sizes.

The project ZIP already contains the correct resource files in their Minecraft paths.
For reference, mod id remains infinitechest so existing item ids/saves are not renamed.
